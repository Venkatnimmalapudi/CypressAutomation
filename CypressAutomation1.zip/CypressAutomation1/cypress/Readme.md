Prereqsites :

Install Node.js
install cypress through below commands
npm install cypress --save-dev

test run through BDD feature file 
execute below command in Terminal 
cypress run --spec cypress\integration\examples\BDDRhipe\Rhipe.feature --headed chrome 


test run throuh  SignUpTest.js file 

Execute below comman in Terminal
1) node_modules\.bin\cypress open
2) Test runner open and select Chrome browser
3)Select SignupTest