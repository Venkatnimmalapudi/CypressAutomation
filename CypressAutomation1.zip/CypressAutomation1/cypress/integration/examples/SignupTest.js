/// <reference types="Cypress" />
import SignupPage from '../../support/pageObjects/SignupPage'
const signpage1 =new SignupPage()


describe('E2E  Automation Test Suite', function() 
 {
  
    it('Sign Up test case', function() 
     {
      //Opem the Signup url
        cy.visit(Cypress.env('url'))

        //Fill the General contact details in the form
        signpage1.General_Contact()
        
        //Change billing addrress 
        signpage1.Billing_Address()

        //Fill the Authorised Contact details in form 
        signpage1.Authorised_Contact()

        //Verfiy the Mandatory fields  to be filled as expected 
        signpage1.Mandatory_Filled_Fields()
      
       
    })
  })


  