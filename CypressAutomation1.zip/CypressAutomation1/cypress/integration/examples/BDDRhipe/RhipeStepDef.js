import SignupPage from '../../../support/pageObjects/SignupPage'
import ProductPage from '../../../support/pageObjects/ProductPage'
import { Given,When,Then, And } from "cypress-cucumber-preprocessor/steps";

const signpage =new SignupPage()

Given('I open Rhipe Page', function()
{
    cy.visit(Cypress.env('url'))
})

//    When I fill the General contact form  details
When('I fill the General contact form  details',function ()
{  
    signpage.General_Contact()
   
})

//    And Checked different address for billing
And('I Checked different address for billing',function ()
{  
    signpage.Billing_Address()
   
})

//    And fill the authorised contact details
And('I fill the authorised contactt form  details',function ()
{  
    signpage.Authorised_Contact()
   
})

//    Then validate the Mandatory fields
Then('Validate the Mandatory fields to be filled',function ()
{  
    signpage.Mandatory_Filled_Fields()
   
})