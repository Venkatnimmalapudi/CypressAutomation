

class SignupPage{

    
     General_Contact ( )
    {
        cy.get('#CustomerName').type('Cloud Solutions');
        cy.get('#RegistrationNumber').type('A123456');
        cy.get('#Street1').click({force: true}).type('20 Cooper Square')
        cy.get('#Street2').type('Dollars street');
        cy.get('#Street3').type('Greenliving residency');
        cy.get('#City').type('Newyork',{force: true});
        cy.get('#State').type('NY',{force: true});
        cy.get('#Country').select('United States',{force: true});
        cy.get('#Postcode').type('10003');
        cy.get('#MainPhone').type('+164567123456',{force: true});
        cy.get('#Fax').type('7123456',{force: true});
        cy.get('#WebUrl').type('Cloudsolutions.com',{force: true});
        cy.get('#Source').select('Rhipe Website',{force: true});
        cy.get('#IndustryType').select('Business Service Consultant',{force: true});
 
    }
    
    Billing_Address()
    {   
        cy.get('#useanotheraddress').check({force: true});
        cy.get('#BillingAddressLine1').type('Frankenallee 221',{force: true});
        cy.get('#BillingCity').type('Texas');
        cy.get('#BillingState').type('NY');
        cy.get('#BillingCountry').select('United States',{force: true});
        cy.get('#BillingPostcode').type('12003',{force: true});

    }
    Authorised_Contact ( )
    {
        cy.get('#PrimaryContactFirstName').type('Test');
        cy.get('#PrimaryContactLastName').type('QA');
        cy.get('#PrimaryContactPhone').type('+14312355466');
        cy.get('#PrimaryContactEmail').type('testing23.com');
        cy.get('#PrimaryContactJobTitle').type('Product Owner');
      
       
    }

    Mandatory_Filled_Fields()
    {
        cy.get('#CustomerName').should('have.value', 'Cloud Solutions')
        cy.get('#RegistrationNumber').should('have.value', 'A123456');
        cy.get('#Street1').should('have.value', '20 Cooper Square');
        cy.get('#Country').should('have.value', 'US');
        cy.get('#Postcode').should('have.value', '10003');
        cy.get('#MainPhone').should('have.value', '+164567123456');
        cy.get('#WebUrl').should('have.value', 'Cloudsolutions.com');
        cy.get('[type="checkbox"]').should('be.checked')
        cy.get('#BillingAddressLine1').should('have.value','Frankenallee 221');
        cy.get('#BillingCity').should('have.value','Texas');
        cy.get('#BillingCountry').should('have.value','US');
        cy.get('#BillingPostcode').should('have.value','12003');
        cy.get('#PrimaryContactFirstName').should('have.value', 'Test');
        cy.get('#PrimaryContactLastName').should('have.value', 'QA');
        cy.get('#PrimaryContactPhone').should('have.value', '+14312355466');
        cy.get('#PrimaryContactEmail').should('have.value', 'testing23.com');
        cy.get('#usesamecontact').should('be.checked')

    }
  
 
}


export default SignupPage;